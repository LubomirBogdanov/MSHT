'template_user.h' is only a template file
When porting the applications to a platform which is not supportted in CC3100 SDK, user has to modify this file accordingly

'user.h' available at 'cc3100-sdk\platform\msp430fr5739' is ported to 'MSP430FR5739 + Non-OS Environment' - It can be used as
a reference
