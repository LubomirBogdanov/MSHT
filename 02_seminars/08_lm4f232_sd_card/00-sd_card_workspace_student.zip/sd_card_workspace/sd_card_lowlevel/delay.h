/*
 * delay.h
 *
 *  Created on: May 14, 2015
 *      Author: Lubo
 */

#ifndef DELAY_H_
#define DELAY_H_

void init_delay(void);
void delay_us(unsigned long delay);
void delay_ms(unsigned long delay);

#endif /* DELAY_H_ */
