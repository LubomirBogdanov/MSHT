#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "utils/uartstdio.h"
#include "driverlib/ssi.h"
#include "delay.h"

/* Definitions for MMC/SDC command */
#define CMD0    (0x40+0)    /* GO_IDLE_STATE */
#define CMD1    (0x40+1)    /* SEND_OP_COND */
#define CMD8    (0x40+8)    /* SEND_IF_COND */
#define CMD9    (0x40+9)    /* SEND_CSD */
#define CMD10    (0x40+10)    /* SEND_CID */
#define CMD12    (0x40+12)    /* STOP_TRANSMISSION */
#define CMD16    (0x40+16)    /* SET_BLOCKLEN */
#define CMD17    (0x40+17)    /* READ_SINGLE_BLOCK */
#define CMD18    (0x40+18)    /* READ_MULTIPLE_BLOCK */
#define CMD23    (0x40+23)    /* SET_BLOCK_COUNT */
#define CMD24    (0x40+24)    /* WRITE_BLOCK */
#define CMD25    (0x40+25)    /* WRITE_MULTIPLE_BLOCK */
#define CMD41    (0x40+41)    /* SEND_OP_COND (ACMD) */
#define CMD55    (0x40+55)    /* APP_CMD */
#define CMD58    (0x40+58)    /* READ_OCR */

/*-----------------------------------------------------------------------*/
/* Receive a byte from MMC via SPI  (Platform dependent)                 */
/*-----------------------------------------------------------------------*/
static uint8_t rcvr_spi(void) {
	uint32_t rcvdat;

	ROM_SSIDataPut(SSI0_BASE, 0xFF); /* write dummy data */

	ROM_SSIDataGet(SSI0_BASE, &rcvdat); /* read data frm rx fifo */

	return (uint8_t) rcvdat;
}

/*-----------------------------------------------------------------------*/
/* Transmit a byte to MMC via SPI  (Platform dependent)                  */
/*-----------------------------------------------------------------------*/
static void xmit_spi(uint8_t dat) {
	uint32_t rcvdat;

	ROM_SSIDataPut(SSI0_BASE, dat); /* Write the data to the tx fifo */

	ROM_SSIDataGet(SSI0_BASE, &rcvdat); /* flush data read during the write */
}

/*-----------------------------------------------------------------------*/
/* Wait for card ready                                                   */
/*-----------------------------------------------------------------------*/
static uint8_t wait_ready(void) {
	uint8_t res;

	rcvr_spi();
	do
		res = rcvr_spi();
	while (res != 0xFF);

	return res;
}

static uint8_t send_cmd(uint8_t cmd, uint32_t arg) {
	uint8_t n, res;

	if (wait_ready() != 0xFF)
		return 0xFF;

	/* Send command packet */
	xmit_spi(cmd); /* Command */
	xmit_spi((uint8_t)(arg >> 24)); /* Argument[31..24] */
	xmit_spi((uint8_t)(arg >> 16)); /* Argument[23..16] */
	xmit_spi((uint8_t)(arg >> 8)); /* Argument[15..8] */
	xmit_spi((uint8_t) arg); /* Argument[7..0] */
	n = 0xff;
	if (cmd == CMD0)
		n = 0x95; /* CRC for CMD0(0) */
	if (cmd == CMD8)
		n = 0x87; /* CRC for CMD8(0x1AA) */
	xmit_spi(n);

	/* Receive command response */
	if (cmd == CMD12)
		rcvr_spi(); /* Skip a stuff byte when stop reading */
	n = 10; /* Wait for a valid response in timeout of 10 attempts */
	do
		res = rcvr_spi();
	while ((res & 0x80) && --n);

	return res; /* Return with the response value */
}

// set the SSI speed to the max setting
static void set_max_speed(void) {
	unsigned long i;

	/* Disable the SSI */
	ROM_SSIDisable(SSI0_BASE);

	/* Set the maximum speed as half the system clock, with a max of 12.5 MHz. */
	i = ROM_SysCtlClockGet() / 2;
	if (i > 12500000) {
		i = 12500000;
	}

	/* Configure the SSI0 port to run at 12.5MHz */
	ROM_SSIConfigSetExpClk(SSI0_BASE, ROM_SysCtlClockGet(), SSI_FRF_MOTO_MODE_0, SSI_MODE_MASTER, i, 8);

	/* Enable the SSI */
	ROM_SSIEnable(SSI0_BASE);
}

/*-----------------------------------------------------------------------*/
/* Send 80 or so clock transitions with CS and DI held high. This is     */
/* required after card power up to get it into SPI mode                  */
/*-----------------------------------------------------------------------*/
static void send_initial_clock_train(void) {
	unsigned int i;
	unsigned long dat;

	/* Ensure CS is held high. */
	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3);

	/* Switch the SSI TX line to a GPIO and drive it high too. */
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_5);
	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_5, GPIO_PIN_5);

	/* Send 10 bytes over the SSI. This causes the clock to wiggle the */
	/* required number of times. */
	for (i = 0; i < 10; i++) {
		/* Write DUMMY data. SSIDataPut() waits until there is room in the */
		/* FIFO. */
		ROM_SSIDataPut(SSI0_BASE, 0xFF);

		/* Flush data read during data write. */
		ROM_SSIDataGet(SSI0_BASE, &dat);
	}

	/* Revert to hardware control of the SSI TX line. */
	ROM_GPIOPinTypeSSI(GPIO_PORTA_BASE, GPIO_PIN_5);
}

int main(void) {
	uint8_t type, ocr[4], in[512], out[512];
	unsigned int j, i;

	// Set the system clock to run at 50MHz from the PLL.
	ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

	// Enable the peripherals used by this example.
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);
	ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

	// Enable Interrupts
	ROM_IntMasterEnable();

	// Set GPIO A0 and A1 as UART.
	ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

	// Initialize the UART as a console for text I/O.
	UARTStdioInit(0);

	init_delay();

	// Print hello message to user.
	UARTprintf("\n\rSD Card low level SPI commands\n\r");

	/*
	 * Configure the appropriate pins to be SSI instead of GPIO. The FSS (CS)
	 * signal is directly driven to ensure that we can hold it low through a
	 * complete transaction with the SD card.
	 */
	ROM_GPIOPinTypeSSI(GPIO_PORTA_BASE, GPIO_PIN_5 | GPIO_PIN_4 | GPIO_PIN_2);
	ROM_GPIOPinTypeGPIOOutput(GPIO_PORTA_BASE, GPIO_PIN_3); //FSS

	/*
	 * Set the SSI output pins to 4MA drive strength and engage the
	 * pull-up on the receive line.
	 */
	ROM_GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_4, GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD_WPU);
	ROM_GPIOPadConfigSet(GPIO_PORTA_BASE, GPIO_PIN_2 | GPIO_PIN_5 | GPIO_PIN_3, GPIO_STRENGTH_4MA, GPIO_PIN_TYPE_STD);

	/* Configure the SSI0 port */
	ROM_SSIConfigSetExpClk(SSI0_BASE, ROM_SysCtlClockGet(), SSI_FRF_MOTO_MODE_0, SSI_MODE_MASTER, 400000, 8);
	ROM_SSIEnable(SSI0_BASE);

	//--------------------------------------------------------------------
  //---------------------------INIT SD----------------------------------
	//--------------------------------------------------------------------

	//Configure card interface for SPI operation
	?????

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, 0); //FSS

	send_cmd(CMD0, 0); //Reset
	send_cmd(CMD8, 0x1AA);
	for (i = 0; i < 4; i++){
		in[i] = rcvr_spi();
	}

	while(send_cmd(CMD55, 0) <= 1 && send_cmd(CMD41, 1UL << 30) != 0){ }

	send_cmd(CMD58, 0);
	for (i = 0; i < 4; i++){
		ocr[i] = rcvr_spi();
	}
	type = (ocr[0] & 0x40) ? 6 : 2;

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3); //FSS

	rcvr_spi();            // Idle

	UARTprintf("Type = %d\n\r", type);
	set_max_speed();
	UARTprintf("Max speed set!\n\r");

	//--------------------------------------------------------------------
  //---------------------------WRITE------------------------------------
	//--------------------------------------------------------------------
	UARTprintf("1. Initializing buffer\n\r");
	
	//Initialize out[ ] buffer with 512 bytes
	?????

	UARTprintf("2. Writing block...");

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, 0); //FSS
	//Send the appropriate command for writing
	send_cmd(?????, 16384);

	xmit_spi(0xFE);                    // Xmit data token

	for(i = 0; i < 512; i++) {
		xmit_spi(out[i]);
	}

	xmit_spi(0xFF);                    // CRC (Dummy)
	xmit_spi(0xFF);

	/// Receive data response
	if ((rcvr_spi() & 0x1F) != 0x05) {     // If not accepted, return with error
		UARTprintf("ERROR: not accepted!\n\r");
		while (1) { }
	}
	UARTprintf("DONE!\n\r");

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3); //FSS

	//--------------------------------------------------------------------
    //---------------------------READ-------------------------------------
	//--------------------------------------------------------------------
	UARTprintf("3. Reading block...\n\r");

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, 0); //FSS

	//Send the appropriate command for reading
	send_cmd(?????, 16384);

	UARTprintf("4. Waiting 0xFE token:");
	do {
		in[0] = rcvr_spi();
		UARTprintf(" 0x%02X", in[0]);
	} while (in[0] == 0xFF);

	if (in[0] != 0xFE) { // If not valid data token, return with error
		UARTprintf("ERROR: wrong data token returned!\n\r");
		while (1) { }
	}
	UARTprintf("\n\r5. Receiving 512 bytes...\n\r");

	//Call rcvr_spi() 512 times to fill in[ ] buffer
	?????

	rcvr_spi(); // Discard CRC
	rcvr_spi();

	ROM_GPIOPinWrite(GPIO_PORTA_BASE, GPIO_PIN_3, GPIO_PIN_3); //FSS

	//--------------------------------------------------------------------
  //---------------------------DISPLAY----------------------------------
	//--------------------------------------------------------------------
	for (i = 0; i < 512; i++) {
		UARTprintf("0x%02X ", in[i]);
		if ((i % 16) == 0) {
			UARTprintf("\n\r");
		}
	}

	UARTprintf("\n\rProgram end.\n\r");

	while (1) {	}
}
