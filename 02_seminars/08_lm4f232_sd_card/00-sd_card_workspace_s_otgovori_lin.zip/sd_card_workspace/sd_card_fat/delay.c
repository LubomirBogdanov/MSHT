/*
 * delay.c
 *
 *  Created on: May 14, 2015
 *      Author: Lubo
 */
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "utils/ustdlib.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"
#include "utils/uartstdio.h"

static unsigned long ul_ProcClock;

void init_delay()
{
	ul_ProcClock = SysCtlClockGet();
	UARTprintf("\n\rProcessor clock: %d Hz\n\r", ul_ProcClock);
}

void delay_us(unsigned long delay)
{
	delay *= ul_ProcClock/3000000;
	SysCtlDelay(delay);
}

void delay_ms(unsigned long delay)
{
	delay *= ul_ProcClock/3000;
	SysCtlDelay(delay);
}
