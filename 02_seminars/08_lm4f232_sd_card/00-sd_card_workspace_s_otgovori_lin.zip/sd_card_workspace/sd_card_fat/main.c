#include <string.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "utils/uartstdio.h"
#include "fatfs/src/ff.h"
#include "fatfs/src/diskio.h"

//*****************************************************************************
// This is the handler for this SysTick interrupt.  FatFs requires a timer tick
// every 10 ms for internal timing purposes.
//*****************************************************************************
void SysTickHandler(void)
{
    // Call the FatFs tick timer.
    disk_timerproc();
}

int main(void)
{
    WORD bytes_written;
    static FATFS fatfs;
    static FIL myfile;

    char *msg = "Hello, world!"; //13 chars

    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    ROM_FPULazyStackingEnable();

    // Set the system clock to run at 50MHz from the PLL.
    ROM_SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    // Enable the peripherals used by this example.
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    // Configure SysTick for a 100Hz interrupt.  The FatFs driver wants a 10 ms tick.
    ROM_SysTickPeriodSet(ROM_SysCtlClockGet() / 100);
    ROM_SysTickEnable();
    ROM_SysTickIntEnable();

    // Enable Interrupts
    ROM_IntMasterEnable();

    // Set GPIO A0 and A1 as UART.
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    // Initialize the UART as a console for text I/O.
    UARTStdioInit(0);

    // Print hello message to user.
    UARTprintf("\n\r\n\rSD Card FAT\n\r");

    // Mount the file system, using logical disk 0.
    f_mount(0, &fatfs);

    f_open(&myfile, "myfile.txt", FA_WRITE | FA_CREATE_NEW);

    f_write(&myfile, msg, 13, &bytes_written);

    f_close(&myfile);

    // Unmount the file system
    f_mount(0, NULL);

    UARTprintf("DONE!\n\r");

    while(1){ }
}
