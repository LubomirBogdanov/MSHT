#include "board.h"
#include "FreeRTOS.h"
#include "task.h"

#define DELAY_1ms	configTICK_RATE_HZ/1000
#define DELAY_40ms	configTICK_RATE_HZ/25
#define DELAY_100ms	configTICK_RATE_HZ/10
#define DELAY_250ms configTICK_RATE_HZ/4

static void prvSetupHardware(void)
{
	SystemCoreClockUpdate();
	Board_Init();
}

static void vLCDTask1(void *pvParameters)
{
	SPI_DELAY_CONFIG_T DelayConfigStruct;
	SPI_DATA_SETUP_T XfSetup;
	uint16_t spi_tx_byte;
	uint16_t spi_rx_byte;

	Chip_GPIO_SetPinDIROutput( LPC_GPIO_PORT, 0, 4); //P0.4 - output,  RS
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, 0, 4, 0); //RS=0 send instructions

	Chip_GPIO_SetPinDIROutput( LPC_GPIO_PORT, 0, 5); //P0.5 - output,  Reset
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, 0, 5, 1); //Reset=1


	Chip_SWM_Init(); //Enable switch matrix clock

	LPC_SWM->PINASSIGN[0] |= 0xFF; // Give back control UART_TX -> GPIO pin, LPCOpen lacks such function

	Chip_SWM_MovablePinAssign(SWM_SPI0_SCK_IO, 12);
	Chip_SWM_MovablePinAssign(SWM_SPI0_MOSI_IO, 14);
	Chip_SWM_MovablePinAssign(SWM_SPI0_SSEL_IO, 13);

	Chip_SWM_Deinit(); //Disable switch matrix clock to save power

	Chip_SPI_Init(LPC_SPI0);
	Chip_SPI_ConfigureSPI(LPC_SPI0, SPI_MODE_MASTER | SPI_CLOCK_CPHA0_CPOL0 | SPI_CFG_MSB_FIRST_EN);
	LPC_SPI0->DIV = 1000; //LPCOpen lacks DIV manipulation function
	DelayConfigStruct.FrameDelay = 0;
	DelayConfigStruct.TransferDelay = 0;
	DelayConfigStruct.PostDelay = 100;
	DelayConfigStruct.PreDelay = 100;
	Chip_SPI_DelayConfig(LPC_SPI0, &DelayConfigStruct);
	Chip_SPI_Enable(LPC_SPI0);

	XfSetup.Length = 1;
	XfSetup.pTx = &spi_tx_byte;
	XfSetup.RxCnt = XfSetup.TxCnt = 0;
	XfSetup.DataSize = 8;
	XfSetup.pRx = &spi_rx_byte;


	vTaskDelay(DELAY_100ms); // >40ms

	// Function set
	spi_tx_byte = 0x38;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us


	// Function set
	spi_tx_byte = 0x39;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// Internal OSC frequency
	spi_tx_byte = 0x14;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// Contrast set
	spi_tx_byte = 0x78;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// Power/ICON/Contrast control
	spi_tx_byte = 0x5E;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// Follower control
	spi_tx_byte = 0x6C;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_250ms); // >200ms

	// Display ON/OFF control
	spi_tx_byte = 0x0F;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// Clear Display
	spi_tx_byte = 0x01;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_40ms); // >20ms

	// Entry mode set
	spi_tx_byte = 0x06;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// DDRAM AC
	spi_tx_byte = 0x80;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	//RS=1  send data to LCD
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, 0, 4, 1);
	vTaskDelay(DELAY_1ms);

	// data
	spi_tx_byte = 0x30;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// data
	spi_tx_byte = 0x31;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	// data
	spi_tx_byte = 0x32;
	Chip_SPI_RWFrames_Blocking(LPC_SPI0, &XfSetup);
	vTaskDelay(DELAY_1ms); // >26us

	while(1){ }

}

int main(void)
{
	prvSetupHardware();

	xTaskCreate(vLCDTask1, "vLCDTask1",	configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL), (TaskHandle_t *) NULL);

	vTaskStartScheduler();

	return 1;
}

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
	DEBUGSTR("Stack Over flow in :");
	DEBUGSTR(pcTaskName);
	/* Run time stack overflow checking is performed if
	   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	   function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	for (;; ) {}
}
