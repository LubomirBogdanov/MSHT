#include "board.h"
#include "spi_8xx.h"



#define RW_TEST             1
#define LOOPBACK_TEST       0
#define BUFFER_SIZE         10
#define SPI_MODE_TEST       (SPI_MODE_MASTER)
#define POLLING_MODE        1
#define LPC_SPI           LPC_SPI0

static uint16_t TxBuf[BUFFER_SIZE] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
static uint16_t RxBuf[BUFFER_SIZE];

static SPI_DELAY_CONFIG_T DelayConfigStruct;
static SPI_DATA_SETUP_T XfSetup;

int main(void)
{
	volatile unsigned long i;
	uint16_t ch = 0x55;
	uint32_t Status;

	SystemCoreClockUpdate();
	Board_Init();

	Chip_IOCON_PinSetMode(LPC_IOCON, IOCON_PIO14, PIN_MODE_PULLUP);

	Chip_SWM_Init();
	/*
	 * Initialize SSP0 pins connect
	 * SCK1: PINASSIGN4[31:24]: Select P0.12
	 * MOSI1: PINASSIGN5[7:0]: Select P0.14
	 * MISO1: PINASSIGN5[15:8] : Select P0.6
	 * SSEL1: PINASSIGN5[23:16]: Select P0.13
	 */
	Chip_SWM_DisableFixedPin(SWM_FIXED_VDDCMP);
	Chip_SWM_MovablePinAssign(SWM_SPI0_SCK_IO, 12);
	Chip_SWM_MovablePinAssign(SWM_SPI0_MOSI_IO, 14);
	Chip_SWM_MovablePinAssign(SWM_SPI0_MISO_IO, 6);
	Chip_SWM_MovablePinAssign(SWM_SPI0_SSEL_IO, 13);

	Chip_SWM_Deinit();

	Chip_SPI_Init(LPC_SPI);
	Chip_SPI_ConfigureSPI(LPC_SPI, SPI_MODE_MASTER | SPI_CLOCK_CPHA1_CPOL1 | SPI_CFG_MSB_FIRST_EN);
	DelayConfigStruct.FrameDelay = 0;
	DelayConfigStruct.PostDelay = 0;
	DelayConfigStruct.PreDelay = 0;
	DelayConfigStruct.TransferDelay = 0;
	Chip_SPI_DelayConfig(LPC_SPI, &DelayConfigStruct);
	Chip_SPI_Enable(LPC_SPI);

	XfSetup.Length = 1;
	XfSetup.pTx = &ch;
	XfSetup.RxCnt = XfSetup.TxCnt = 0;
	XfSetup.DataSize = 8;
	XfSetup.pRx = RxBuf;

	LPC_SPI->DIV = 10000;

	while(1){
		Chip_SPI_RWFrames_Blocking(LPC_SPI, &XfSetup);

		for(i = 0; i < 200000; i++){}
	}

}
