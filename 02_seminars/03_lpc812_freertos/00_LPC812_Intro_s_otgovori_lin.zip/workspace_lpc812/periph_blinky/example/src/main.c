#include "board.h"
#include <stdio.h>

int main(void)
{
	volatile unsigned long i;

	SystemCoreClockUpdate();
	Board_Init();

	while (1) {
		Board_LED_Set(0, false);
		for(i = 0; i < 200000; i++){ }
		Board_LED_Set(0, true);
		for(i = 0; i < 200000; i++){ }
	}
}
