#include "board.h"
#include <stdio.h>

void PININT0_IRQHandler(void)
{
	Chip_PININT_ClearIntStatus(LPC_PININT, PININTCH0);
	Board_LED_Toggle(1);
}

int main(void)
{
	SystemCoreClockUpdate();
	Board_Init();

	Chip_GPIO_SetPinDIRInput(LPC_GPIO_PORT, 0, 15);
	Chip_SYSCTL_SetPinInterrupt(0, 15);
	Chip_IOCON_PinSetMode(LPC_IOCON, 15, 0x02);
	Chip_PININT_SetPinModeEdge(LPC_PININT, PININTCH0);
	Chip_PININT_EnableIntLow(LPC_PININT, PININTCH0);   //Falling edge
	NVIC_EnableIRQ(PININT0_IRQn);

	while (1) {
		__WFI();
	}
}
