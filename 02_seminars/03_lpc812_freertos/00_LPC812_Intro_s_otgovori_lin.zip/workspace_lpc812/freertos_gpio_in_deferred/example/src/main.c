#include "board.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

QueueHandle_t xBinarySemaphore;

static void prvSetupHardware(void)
{
	SystemCoreClockUpdate();
	Board_Init();
}

void PININT0_IRQHandler(void)
{
	Chip_PININT_ClearIntStatus(LPC_PININT, PININTCH0);

	xSemaphoreGiveFromISR( xBinarySemaphore, NULL );
	portYIELD_FROM_ISR( NULL );
}

static void xDeferTask(void *pvParameters)
{
	while(1){

		xSemaphoreTake( xBinarySemaphore, portMAX_DELAY );

		for(uint8_t i = 0; i < 3; i++){
			Board_LED_Set(1, 1);
			vTaskDelay(configTICK_RATE_HZ/2);
			Board_LED_Set(1, 0);
			vTaskDelay(configTICK_RATE_HZ/2);
		}
	}
}

static void vLEDTask0 (void *pvParameters) {

	Chip_GPIO_SetPinDIRInput(LPC_GPIO_PORT, 0, 15);
	Chip_SYSCTL_SetPinInterrupt(0, 15);
	Chip_IOCON_PinSetMode(LPC_IOCON, 15, 0x02);
	Chip_PININT_SetPinModeEdge(LPC_PININT, PININTCH0);
	Chip_PININT_EnableIntLow(LPC_PININT, PININTCH0);   //Falling edge
	NVIC_EnableIRQ(PININT0_IRQn);

	while (1) {
		Board_LED_Toggle(0);
		vTaskDelay(configTICK_RATE_HZ);
	}
}

int main(void)
{
	prvSetupHardware();

	xBinarySemaphore = xSemaphoreCreateBinary();

	xTaskCreate(vLEDTask0, "vTaskLed0", configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL), (TaskHandle_t *) NULL);
	xTaskCreate(xDeferTask, "vDeferTask", configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 2UL), (TaskHandle_t *) NULL);

	vTaskStartScheduler();

	return 1;
}

/**
 * Override stack overflow function so that it won't use printf [DEBUGOUT]
 */
void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
	DEBUGSTR("Stack Over flow in :");
	DEBUGSTR(pcTaskName);
	/* Run time stack overflow checking is performed if
	   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	   function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	for (;; ) {}
}
