FreeRTOS Blinky Example
=======================

Example Description
-------------------
Welcome to the FreeRTOS basic blinky example. This example starts up
FreeRTOS and creates 3 tasks that blink LEDs at different rates.

This example does not use the RS-232 port.

Special Connection Requirements
-------------------------------
Board [NXP_LPCXPRESSO_812]:
There are no special connection requirements for this example.

Board [NXP_812_MAX]:
There are no special connection requirements for this example.

Board [NXP_LPCXPRESSO_824]:
There are no special connection requirements for this example.

Build procedures:
Visit the <a href="http://www.lpcware.com/content/project/lpcopen-platform-nxp-lpc-microcontrollers/lpcopen-v200-quickstart-guides">LPCOpen quickstart guides</a>
to get started building LPCOpen projects.
