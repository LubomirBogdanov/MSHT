#include "board.h"
#include "FreeRTOS.h"
#include "task.h"

static void prvSetupHardware(void)
{
	SystemCoreClockUpdate();
	Board_Init();
}

static void vLEDTask1 (void *pvParameters) {

	while (1) {
		Board_LED_Toggle(1);

		vTaskDelay(configTICK_RATE_HZ/10);
	}
}

int main(void)
{
	prvSetupHardware();

	xTaskCreate(vLEDTask1, "vTaskLed1", configMINIMAL_STACK_SIZE, NULL, (tskIDLE_PRIORITY + 1UL), (TaskHandle_t *) NULL);

	vTaskStartScheduler();

	return 1;
}

/**
 * Override stack overflow function so that it won't use printf [DEBUGOUT]
 */
void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
	DEBUGSTR("Stack Over flow in :");
	DEBUGSTR(pcTaskName);
	/* Run time stack overflow checking is performed if
	   configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	   function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	for (;; ) {}
}
