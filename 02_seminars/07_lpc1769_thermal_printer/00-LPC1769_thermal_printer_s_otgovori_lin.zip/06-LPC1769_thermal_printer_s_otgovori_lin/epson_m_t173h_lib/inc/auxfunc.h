/*
 * auxfunc.h
 *
 *  Created on: 12.05.2014
 *      Author: lbogdanov
 */

#ifndef AUXFUNC_H_
#define AUXFUNC_H_

#include <stdint.h>
#include "uartstdio.h"

uint8_t gethex1();
uint16_t gethex();
char toupper(char CharToBeConverted);

#endif /* AUXFUNC_H_ */
