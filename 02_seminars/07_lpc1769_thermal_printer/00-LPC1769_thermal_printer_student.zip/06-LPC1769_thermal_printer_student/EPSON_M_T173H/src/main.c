#include <cr_section_macros.h>
#include <NXP/crp.h>
#include "LPC17xx.h"
#include <stdint.h>
#include "uartstdio.h"
#include "epson_m_t173h.h"

__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;

int main (void)
{
  int i;
  int choice;
  uint8_t TempBuff[48];

  uint8_t Line0[48];
  uint8_t Line1[48];
  uint8_t Line2[48];
  uint8_t Line3[48];
  uint8_t Line4[48];
  uint8_t Line5[48];
  uint8_t Line6[48];
  uint8_t Line7[48];
  uint8_t Line8[48];
  uint8_t Line9[48];
  uint16_t LineIntensity[10];

  initPrinter();
  UARTStdioInit();

  while(1)
  {
	  UARTprintf("\n\r*****EPSON Thermal Line Printer Test Firmware v1.1*****\n\r");
	  UARTprintf("1. Feed paper.\n\r");
	  UARTprintf("2. Print a line.\n\r");
	  UARTprintf("3. Print 10 lines at once.\n\r");
	  UARTprintf("4. Print 10 lines with intensity.\n\r");
	  UARTprintf("Enter choice:");
	  choice = UARTgetc();
	  UARTprintf("\n\r\n\r");

	  switch(choice)
	  {
	  case '1':
		  UARTprintf("1. Feed paper.\n\r");
		  //Извикай функция за захранване с хартия тук

		  UARTprintf("DONE!\n\r");
		  break;
	  case '2':
		  UARTprintf("2. Print a line.\n\r");
		  //Инициализирай масива TempBuff с данни за една линия тук

		  //Извикай функция за принтиране на данните от TempBuff на един ред тук

		  UARTprintf("DONE!");
		  break;
	  case '3':
		  UARTprintf("3. Print 10 lines at once.\n\r");
		  //Инициализирай масиви Line0 - Line9 с данни тук

		  //Извикай функция за принтиране на данните от масиви Line0 - Line9 тук

		  UARTprintf("DONE!");
		  break;
	  case '4':
		  UARTprintf("4. Print 10 lines with intensity.\n\r");
		  //Инициализирай масиви Line0 - Line9 и LineIntensity с данни тук

		  //Извикай функция за принтиране на данните от масиви Line0 - Line9 с интензитет тук

		  UARTprintf("DONE!");
		  break;
	  default:
		  break;
	  }
  }
}
