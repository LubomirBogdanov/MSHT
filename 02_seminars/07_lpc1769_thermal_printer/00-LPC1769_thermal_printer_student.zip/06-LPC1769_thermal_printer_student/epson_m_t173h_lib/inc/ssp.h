/*
 * ssp.h
 *
 *  Created on: 14.05.2014
 *      Author: lbogdanov
 */

#ifndef __SSP_H__
#define __SSP_H__

#include "LPC17xx.h"
#include <stdint.h>

// SSP CR1 register
#define SSPCR1_SSE		(1 << 1)
// SSP Status register
#define SSPSR_TFE		(1 << 0)
#define SSPSR_TNF		(1 << 1)
#define SSPSR_RNE		(1 << 2)
#define SSPSR_RFF		(1 << 3)
#define SSPSR_BSY		(1 << 4)

#define FIFO_NUM 8 //For LPC1769

void SSP_SSELToggle( uint32_t portnum, uint32_t toggle );
void SSP1Init( );
void SSP1Send(uint8_t *TxData);

#endif /* SSP_H_ */
