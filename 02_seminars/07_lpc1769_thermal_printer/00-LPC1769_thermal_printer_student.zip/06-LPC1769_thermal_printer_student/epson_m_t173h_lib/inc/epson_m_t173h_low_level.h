/*
 * epson_m_t173h_low_level.h
 *
 *  Created on: 15.05.2014
 *      Author: lbogdanov
 */

#ifndef EPSON_M_T173H_LOW_LEVEL_H_
#define EPSON_M_T173H_LOW_LEVEL_H_

#include "LPC17xx.h"
#include "uartstdio.h"
#include "timer.h"
#include "auxfunc.h"
//#include "adc.h"
#include "ssp.h"
#include "timer.h"

#define PRN_PH_A 0x08 //P2.3 <-> PWM1.4
#define PRN_PH_B 0x10 //P2.4 <-> PWM1.5
#define PRN_POW_EN  0x08000000; //P0.27
#define PRN_STBA 0x01 //P2.0
#define PRN_STBB 0x02 //P2.1
#define PRN_STBC 0x04 //P2.2

#define PRN_TM 0x00 //P0.23 <-> AD0.0
#define PRN_PENI 0x01 //P0.24 <-> AD0.1

#define PRN_LAT 0x0100 //P0.8 <-> SPI SS
#define LAT_LENGTH_BITS 384
#define LAT_LENGTH_BYTES LAT_LENGTH_BITS/8

#define PLS 800 //in us
#define PLSMAX 800 //in us
#define PLSMIN 1 //in us
#define DEFAULTPLS 100 //in us

//extern volatile uint32_t ADCIntDone;
//extern volatile uint32_t ADCValue[ADC_NUM];

uint8_t DotsBuff[LAT_LENGTH_BYTES]; //384 bits

extern void delayUs(uint8_t timer_num, uint32_t delayInUs);
void copyBuffer(uint8_t *SourceBuffer, uint8_t *DestinationBuffer);

void rushDriveStepperMotor();
void slowUpDriveStepperMotor();
void constantSpeedDriveStepperMotor(int NumOfSteps);
void consecutiveStep(int StepNumber);
int measureTemperature();
void loadInLatchRegister(uint8_t *LatchBuffer);
void clearLatchBuffer();
void energizePrinterHead(uint16_t PLSDelay);
void turnNumberOfSteps(int NumOfSteps);

#endif /* EPSON_M_T173H_LOW_LEVEL_H_ */
