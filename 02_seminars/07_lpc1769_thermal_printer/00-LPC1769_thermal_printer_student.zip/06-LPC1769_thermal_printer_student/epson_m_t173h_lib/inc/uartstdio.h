/*
 * uartstdio.h
 *
 *  Created on: 07.05.2014
 *      Author: lbogdanov
 */

#ifndef UARTSTDIO_H_
#define UARTSTDIO_H_

void UARTStdioInit();
void UARTprintf(const char *Msg);
char UARTgetc();
void UARTputc(uint8_t Character);

#endif /* UARTSTDIO_H_ */
