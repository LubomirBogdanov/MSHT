/*
 * epson_m_t173h.h
 *
 *  Created on: 08.05.2014
 *      Author: lbogdanov
 */

#ifndef EPSON_M_T173H_H_
#define EPSON_M_T173H_H_

void initPrinter();
void feedPaper();
void printLine(uint8_t *DotsBuff);
void printTenLines(
					uint8_t *Line0, uint8_t *Line1,
					uint8_t *Line2,  uint8_t *Line3,
					uint8_t *Line4,  uint8_t *Line5,
					uint8_t *Line6,  uint8_t *Line7,
					uint8_t *Line8,  uint8_t *Line9
					);

int printTenLinesWithIntensity(
					uint8_t *Line0, uint8_t *Line1,
					uint8_t *Line2,  uint8_t *Line3,
					uint8_t *Line4,  uint8_t *Line5,
					uint8_t *Line6,  uint8_t *Line7,
					uint8_t *Line8,  uint8_t *Line9,
					uint16_t *IntensityLevel
					);

#endif /* EPSON_M_T173H_H_ */
