/*
 * ssp.c
 *
 *  Created on: 14.05.2014
 *      Author: lbogdanov
 */

#include "ssp.h"

void SSP1Init( )
{
  volatile uint8_t i, Dummy;

  // Enable AHB clock to the SSP1.
  LPC_SC->PCONP |= (0x1<<10);

  // Further divider is needed on SSP1 clock. Using default divided by 4
  LPC_SC->PCLKSEL0 &= ~(0x3<<20);


  //P0.9 - MOSI, P0.7 - SCK
  LPC_PINCON->PINSEL0 |= 0x00088000;
  LPC_PINCON->PINSEL0 &= 0xFFFBBFFF;

  // Set DSS data to 8-bit, Frame format Ti, CPOL = 0, CPHA = 0, and SCR is 1
  LPC_SSP1->CR0 = 0x0117;

  // SSPCPSR clock prescale register, master mode, minimum divisor is 0x02
  LPC_SSP1->CPSR = 0x02;

  //Clear FIFOs
  for ( i = 0; i < FIFO_NUM; i++ ){
	Dummy = LPC_SSP1->DR;
  }

  // Master mode
  LPC_SSP1->CR1 = SSPCR1_SSE;

  // Set SSPINMS registers to enable interrupts
  // enable all error related interrupts
  //LPC_SSP1->IMSC = SSPIMSC_RORIM | SSPIMSC_RTIM;
}

/*!
 *\brief Sends 8 8-bit numbers over SSP1. No SS is used.
 *
 *\param TxData - a pointer to the data to be transmitted.
 *\return None.
 */
void SSP1Send(uint8_t *TxData)
{
	int i;

	while ( (LPC_SSP0->SR & (SSPSR_TNF|SSPSR_BSY)) != SSPSR_TNF );
	for(i = 0; i < FIFO_NUM; i++){
		LPC_SSP1->DR = *(TxData++);
	}
	while ( LPC_SSP1->SR & SSPSR_BSY );
}
