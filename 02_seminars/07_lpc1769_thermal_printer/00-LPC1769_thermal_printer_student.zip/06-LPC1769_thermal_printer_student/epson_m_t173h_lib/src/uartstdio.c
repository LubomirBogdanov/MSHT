#include "LPC17xx.h"
#include "string.h"
#include <stdint.h>
#include "uart.h"
#include "uartstdio.h"

extern volatile uint32_t UART0Count;
extern volatile uint8_t UART0Buffer[BUFSIZE];

/*!
 * \brief Initialize UART for 57600 bauds, 8-N-1
*/
void UARTStdioInit()
{
	SystemCoreClockUpdate();
	UARTInit(0, 57600);
}

void UARTprintf(const char *Msg)
{
	int StrLength;
	StrLength = strlen(Msg);
	UARTSend( 0, (uint8_t *)Msg, StrLength );
}

char UARTgetc()
{
	while(1)
	{
		if ( UART0Count != 0 )
		{
		  LPC_UART0->IER = IER_THRE | IER_RLS;	// Disable RBR
		  UARTSend( 0, (uint8_t *)UART0Buffer, UART0Count );
		  UART0Count = 0;
		  LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;// Re-enable RBR
		  break;
		}
	}

	return UART0Buffer[0];
}

void UARTputc(uint8_t Character)
{
	UART0Buffer[0] = Character;

	  LPC_UART0->IER = IER_THRE | IER_RLS;	// Disable RBR
	  UARTSend( 0, (uint8_t *)UART0Buffer, 1 );
	  UART0Count = 0;
	  LPC_UART0->IER = IER_THRE | IER_RLS | IER_RBR;// Re-enable RBR
}
