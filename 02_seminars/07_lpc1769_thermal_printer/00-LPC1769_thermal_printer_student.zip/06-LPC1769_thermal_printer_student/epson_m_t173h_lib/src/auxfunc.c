/*
 * auxfunc.c
 *
 *  Created on: 12.05.2014
 *      Author: lbogdanov
 */
#include "auxfunc.h"

char toupper(char CharToBeConverted)
{
	return CharToBeConverted - 0x20;
}

uint8_t gethex1()
{
   char digit;
   digit = UARTgetc();

   if(digit<='9')
     return(digit-'0');
   else
     return((toupper(digit)-'A')+10);
}

uint16_t gethex()
{
   uint8_t lo,hi,lo1, hi1;
   hi1 = gethex1();
   lo1 = gethex1();
   hi = gethex1();
   lo = gethex1();

   if(lo==0xdd)
     return(hi);
   else
     return(hi1*4096 + lo1*256 + hi*16+lo );
}
