/*
 * epson_m_t173h.c
 *
 *  Created on: 08.05.2014
 *      Author: lbogdanov
 */
#include "epson_m_t173h_low_level.h"
#include "epson_m_t173h.h"

uint32_t SlowUpTable[25] = {3013, 2327, 1953, 1712, 1541, 1412, 1310, 1227, 1158, 1099, 1048, 1004, 964, 929, 898, 869, 843, 819, 798, 777, 758, 741, 725, 709, 694 };

/*!
 * \brief Initialize the EPSON M-T173H hardware. Must be called before any other API
 * from this driver and possibly - at the earliest stage of the microcontroller
 * initialization. This will insure that the latch register will be cleared and the
 * thermal head will be turned off to prevent burn out.
 *
 * \return None.
 */
void initPrinter()
{
	LPC_GPIO2->FIODIR |= (PRN_PH_A | PRN_PH_B | PRN_STBA | PRN_STBB | PRN_STBC); //Set pins as outputs
	LPC_GPIO2->FIOCLR |= (PRN_PH_A | PRN_PH_B | PRN_STBA | PRN_STBB | PRN_STBC); //Initialize phases. Turn off thermal head by clearing STBA, B, C.
	LPC_GPIO0->FIODIR |= PRN_POW_EN; //Set pin as output
	LPC_GPIO0->FIOSET |= PRN_POW_EN; //Active low, so initialize it high
	LPC_GPIO0->FIODIR |= PRN_LAT;
	LPC_GPIO0->FIOSET |= PRN_LAT; //Active low, so initialize it high

	init_timer(0 , TIME_INTERVAL);
	enable_timer(0); //Enable timer0 for the delayMs( ) function
	init_timer(1 , TIME_INTERVAL);
	enable_timer(1); //Enable timer1 for the delayUs( ) function

	//ADCInit( ADC_CLK );

	SSP1Init( );
	clearLatchBuffer();
	loadInLatchRegister(DotsBuff);
}

void rushDriveStepperMotor()
{
	volatile int i;

	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	delayMs(0, 3);

	for(i = 0; i < 4; i++)
	{
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		delayMs(0, 3);
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		delayMs(0, 3);
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		delayMs(0, 3);
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		delayMs(0, 3);
	}

	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	delayMs(0, 3);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	delayMs(0, 3);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	delayMs(0, 3);
}

void slowUpDriveStepperMotor()
{
	volatile int i;

	for(i = 0; i < 24; i+=4)
	{
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		delayUs(0, SlowUpTable[i]);
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		delayUs(0, SlowUpTable[i+1]);
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		delayUs(0, SlowUpTable[i+2]);
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		delayUs(0, SlowUpTable[i+3]);
	}

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	delayUs(0, SlowUpTable[24]);
}

void constantSpeedDriveStepperMotor(int NumOfSteps)
{
	int i, j;

	for(i = 0, j = 0; i < NumOfSteps; i++, j++)
	{
		if(j > 4) j = 0;
		consecutiveStep(j);
		delayUs(0, SlowUpTable[24]);
	}
}

void consecutiveStep(int StepNumber)
{
	switch(StepNumber)
	{
	case 0:
		//UARTprintf("step0 ");
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		break;
	case 1:
		//UARTprintf("step1 ");
		LPC_GPIO2->FIOSET |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		break;
	case 2:
		//UARTprintf("step2 ");
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOCLR |= PRN_PH_B;
		break;
	case 3:
		//UARTprintf("step3 ");
		LPC_GPIO2->FIOCLR |= PRN_PH_A;
		LPC_GPIO2->FIOSET |= PRN_PH_B;
		break;
	}
}

int measureTemperature()
{
	//ADCRead( PRN_TM );
	//while ( !ADCIntDone );
	//ADCIntDone = 0;

	//return  ADCValue[PRN_TM];
	return 0;
}

void clearLatchBuffer()
{
	uint16_t i;
	for(i = 0; i < LAT_LENGTH_BYTES; i++ ){
		DotsBuff[i] = 0x00;
	}
}

void loadInLatchRegister(uint8_t *LatchBuffer)
{
	uint8_t i;

	for(i = 0; i < LAT_LENGTH_BYTES; i+=8){
		SSP1Send(LatchBuffer+i);
	}

	LPC_GPIO0->FIOCLR |= PRN_LAT;
	delayUs(1, 1); //t5 LATCH time
	LPC_GPIO0->FIOSET |= PRN_LAT;
	delayUs(1, 1); //t7 LATCH time
}

void energizePrinterHead(uint16_t PLSDelay)
{
	if((PLSDelay <= PLSMAX) && (PLSDelay >= PLSMIN))
	{
		LPC_GPIO2->FIOSET |= PRN_STBA;
		delayUs(1, PLSDelay);
		LPC_GPIO2->FIOCLR |= PRN_STBA;
		delayUs(1, 100);

		LPC_GPIO2->FIOSET |= PRN_STBB;
		delayUs(1, PLSDelay);
		LPC_GPIO2->FIOCLR |= PRN_STBB;
		delayUs(1, 100);

		LPC_GPIO2->FIOSET |= PRN_STBC;
		delayUs(1, PLSDelay);
		LPC_GPIO2->FIOCLR |= PRN_STBC;
		delayUs(1, 100);
	}
	else
	{
		//ERROR: PLS time out of range. Use default.
		LPC_GPIO2->FIOSET |= PRN_STBA;
		delayUs(1, DEFAULTPLS);
		LPC_GPIO2->FIOCLR |= PRN_STBA;
		delayUs(1, 100);

		LPC_GPIO2->FIOSET |= PRN_STBB;
		delayUs(1, DEFAULTPLS);
		LPC_GPIO2->FIOCLR |= PRN_STBB;
		delayUs(1, 100);

		LPC_GPIO2->FIOSET |= PRN_STBC;
		delayUs(1, DEFAULTPLS);
		LPC_GPIO2->FIOCLR |= PRN_STBC;
		delayUs(1, 100);
	}
}

void copyBuffer(uint8_t *SourceBuffer, uint8_t *DestinationBuffer)
{
	uint8_t i;

	for(i = 0; i < LAT_LENGTH_BYTES; i++){
		 *(DestinationBuffer++) = *(SourceBuffer++);
	}
}

//----------------------------HIGH-LEVEL FUNCTIONS-------------------

/*!
 * \brief Turns the stepper motor 10 steps and then stops. This will allow new paper
 * to be inserted into the printer head.
 *
 * \return None.
 */
void feedPaper()
{
	LPC_GPIO0->FIOCLR |= PRN_POW_EN;
	rushDriveStepperMotor();
	slowUpDriveStepperMotor();
	constantSpeedDriveStepperMotor(10);
	rushDriveStepperMotor();
	LPC_GPIO0->FIOSET |= PRN_POW_EN;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
}

/*!
 * \brief Turns the stepper motor certain number of steps.
 *
 * \param NumOfSteps is an integer representing the number of steps that will be turned.
 *
 * \return None.
 */
void turnNumberOfSteps(int NumOfSteps)
{
	if(NumOfSteps < 1) NumOfSteps = 1;
	LPC_GPIO0->FIOCLR |= PRN_POW_EN;
	rushDriveStepperMotor();
	slowUpDriveStepperMotor();
	constantSpeedDriveStepperMotor(NumOfSteps);
	rushDriveStepperMotor();
	LPC_GPIO0->FIOSET |= PRN_POW_EN;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
}

/*!
 * \brief Prints a single line and then stops. Feed paper into the printer before
 * calling this function.
 *
 * \param DotsBuff is a pointer to an array of 48 8-bit unsigned integers. Each bit of
 * them represents a single dot from the printer head. A total of 48 X 8 = 384 bits are
 * available that build up a single line on the paper.
 *
 * \return None.
 */
void printLine(uint8_t *DotsBuff)
{
	LPC_GPIO0->FIOCLR |= PRN_POW_EN;
	rushDriveStepperMotor();
	slowUpDriveStepperMotor();

	//---------------------------------
	//---------------------------------
	constantSpeedDriveStepperMotor(1);

	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;

	loadInLatchRegister(DotsBuff);

	LPC_GPIO2->FIOSET |= PRN_STBA;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBA;
	delayUs(1, 100);

	LPC_GPIO2->FIOSET |= PRN_STBB;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBB;
	delayUs(1, 100);

	LPC_GPIO2->FIOSET |= PRN_STBC;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBC;
	delayUs(1, 100);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;

	LPC_GPIO2->FIOSET |= PRN_STBA;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBA;
	delayUs(1, 100);

	LPC_GPIO2->FIOSET |= PRN_STBB;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBB;
	delayUs(1, 100);

	LPC_GPIO2->FIOSET |= PRN_STBC;
	delayUs(1, PLS);
	LPC_GPIO2->FIOCLR |= PRN_STBC;
	delayUs(1, 100);
	//---------------------------------
	//---------------------------------


	rushDriveStepperMotor();
	LPC_GPIO0->FIOSET |= PRN_POW_EN;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
}

/*!
 * \brief Prints a row of ten lines at once and then stops. Feed paper into the printer
 * before calling this function.
 *
 * \param Line0 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 0.
 * \param Line1 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 1.
 * \param Line2 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 2.
 * \param Line3 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 3.
 * \param Line4 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 4.
 * \param Line5 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 5.
 * \param Line6 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 6.
 * \param Line7 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 7.
 * \param Line8 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 8.
 * \param Line9 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 9.
 *
 * \return None.
 */
void printTenLines(
					uint8_t *Line0, uint8_t *Line1,
					uint8_t *Line2,  uint8_t *Line3,
					uint8_t *Line4,  uint8_t *Line5,
					uint8_t *Line6,  uint8_t *Line7,
					uint8_t *Line8,  uint8_t *Line9
					)
{
	LPC_GPIO0->FIOCLR |= PRN_POW_EN;
	rushDriveStepperMotor();
	slowUpDriveStepperMotor();

	constantSpeedDriveStepperMotor(1);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line0, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line1, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line2, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line3, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(PLSMAX);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line4, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line5, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(PLSMAX);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line6, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line7, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(PLSMAX);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line8, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(PLSMAX);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line9, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(PLSMAX);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(PLSMAX);
	//---------------------------------

	rushDriveStepperMotor();
	LPC_GPIO0->FIOSET |= PRN_POW_EN;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
}

/*!
 * \brief Prints a row of ten lines at once and then stops. This API provides control
 * over the length of the STROBE signal that controls the energizing of the six partitions
 * during the printing of each line. Feed paper into the printer before calling this
 * function.
 *
 * \param Line0 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 0.
 * \param Line1 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 1.
 * \param Line2 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 2.
 * \param Line3 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 3.
 * \param Line4 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 4.
 * \param Line5 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 5.
 * \param Line6 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 6.
 * \param Line7 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 7.
 * \param Line8 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 8.
 * \param Line9 is a pointer to an array of 48 8-bit unsigned integers with dot data for Line 9.
 * \param IntensityLevel is a pointer to an array of 10 16-bit unsigned integers that represent
 * the STROBE duration in microseconds. The allowable values are between 1 and 800 us and
 * must not be exceeded. Otherwise the printer head might be damaged.
 *
 * \return Returns 0 if IntensityLevel[ ] elements are valid. Returns 1 if at least one of
 * the elements is outside of the specified range (1 - 800 us).
 */
int printTenLinesWithIntensity(
					uint8_t *Line0, uint8_t *Line1,
					uint8_t *Line2,  uint8_t *Line3,
					uint8_t *Line4,  uint8_t *Line5,
					uint8_t *Line6,  uint8_t *Line7,
					uint8_t *Line8,  uint8_t *Line9,
					uint16_t *IntensityLevel
					)
{
	int i;
	for(i = 0; i < 10; i++){
		if((IntensityLevel[i] > PLSMAX) || (IntensityLevel[i] < PLSMIN)){
			UARTprintf("ERROR: Intensity level out of range!\n\r");

			return 1;
		}
	}

	LPC_GPIO0->FIOCLR |= PRN_POW_EN;
	rushDriveStepperMotor();
	slowUpDriveStepperMotor();

	constantSpeedDriveStepperMotor(1);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line0, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[0]);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[0]);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line1, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[1]);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[1]);

	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line2, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[2]);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[2]);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line3, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[3]);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[3]);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line4, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[4]);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[4]);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line5, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[5]);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[5]);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line6, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[6]);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[6]);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line7, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[7]);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[7]);
	//---------------------------------
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	copyBuffer(Line8, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[8]);
	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[8]);

	LPC_GPIO2->FIOCLR |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	copyBuffer(Line9, DotsBuff);
	loadInLatchRegister(DotsBuff);
	energizePrinterHead(IntensityLevel[9]);
	LPC_GPIO2->FIOSET |= PRN_PH_A;
	LPC_GPIO2->FIOSET |= PRN_PH_B;
	energizePrinterHead(IntensityLevel[9]);
	//---------------------------------

	rushDriveStepperMotor();
	LPC_GPIO0->FIOSET |= PRN_POW_EN;
	LPC_GPIO2->FIOCLR |= PRN_PH_B;

	return 0;
}
