#include "board.h"
#include <stdio.h>
#include <string.h>

volatile uint16_t bit_count;
uint8_t bit_array[512];
uint8_t bit_array_final[128];

void print_bit_array(void)
{
	uint16_t i;

	DEBUGOUT("bit_array = ");
	for(i = 0; i < 512; i++){
		DEBUGOUT("%01d", bit_array[i]);
	}
	DEBUGOUT("\n");
}

void print_bit_array_final(void)
{
	uint16_t i;

	DEBUGOUT("bit_array_final = ");
	for(i = 0; i < 128; i++){
		DEBUGOUT("%01d", bit_array_final[i]);
	}
	DEBUGOUT("\n");
}

void search_for_tag(uint8_t *bit_arr, uint8_t *bit_arr_final)
{
	uint16_t i;
	uint8_t j;
	uint8_t tag_found;

	for(i = 0; i < (512 - 128); i++){
		if(bit_array[i] == 0){
			for( j = 1; j < 10; j++){
				if(bit_array[i+j] != 0){
					tag_found = 0;
					break;
				}
				else{
					tag_found = 1;
				}
			}

			if(tag_found){
				if(bit_array[i+j] == 1){
					tag_found = 1;
					memcpy(bit_array_final, bit_array+i, 128);
					break;
				}
				else{
					tag_found = 0;
				}
			}
		}
	}

	if(!tag_found){
		memset(bit_array_final, 0x00, 128);
	}
}

void PININT0_IRQHandler(void)
{
	uint8_t pin_value;

	Chip_PININT_ClearIntStatus(LPC_PININT, PININTCH0);

	pin_value = Chip_GPIO_GetPinState(LPC_GPIO_PORT, 0, 15);

	bit_array[bit_count] = pin_value;
	bit_count++ ;

	if(bit_count == 255){
		NVIC_DisableIRQ(PININT0_IRQn);
		search_for_tag(bit_array, bit_array_final);
		//print_bit_array();
		print_bit_array_final();
		bit_count = 0;
		memset(bit_array, 0x00, 512);
		NVIC_EnableIRQ(PININT0_IRQn);
	}
}

int main(void)
{
	SystemCoreClockUpdate();
	Board_Init();

	Board_LED_Set(0, false);

	DEBUGOUT("Starting 128-bit, biphase, 4kbit/s\n\r");

	bit_count = 0;
	memset(bit_array, 0x00, 512);
	memset(bit_array_final, 0x00, 128);

	//Data
	Chip_GPIO_SetPinDIRInput(LPC_GPIO_PORT, 0, 15);

	//Clock
	Chip_GPIO_SetPinDIRInput(LPC_GPIO_PORT, 0, 6);
	Chip_SYSCTL_SetPinInterrupt(0, 6);
	Chip_IOCON_PinSetMode(LPC_IOCON, 6, PIN_MODE_INACTIVE);
	Chip_PININT_SetPinModeEdge(LPC_PININT, PININTCH0);
	Chip_PININT_EnableIntHigh(LPC_PININT, PININTCH0);   //Rising edge
	NVIC_EnableIRQ(PININT0_IRQn);

	//R/W
	Chip_GPIO_SetPinDIROutput(LPC_GPIO_PORT, 0, 7);
	Chip_GPIO_SetPinState(LPC_GPIO_PORT, 0, 7, 1);

	while (1) {
		__WFI();
	}
}
