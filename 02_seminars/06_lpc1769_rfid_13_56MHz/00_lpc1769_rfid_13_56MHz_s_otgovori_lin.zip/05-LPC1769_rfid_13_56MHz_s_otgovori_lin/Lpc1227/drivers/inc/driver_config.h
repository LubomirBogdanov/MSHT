/*******************************************************************************
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
********************************************************************************
*
* Filename:          driver_config.h
* Processor family:  LPC1227
*
* Description: This file contains the configuration defines for the driver.
*
*******************************************************************************/

#ifndef DRIVER_CONFIG_H_
#define DRIVER_CONFIG_H

#include <LPC122x.h>

#define CONFIG_ENABLE_DRIVER_CRP                1
#define CONFIG_CRP_SETTING_NO_CRP               1

/* definitions for i2c link */
#define CONFIG_ENABLE_DRIVER_I2C                1
#define CONFIG_I2C_DEFAULT_I2C_IRQHANDLER       1

/* definitions for SPI link */
#define CONFIG_ENABLE_DRIVER_SSP                1

/* definitions for GPIO */
#define CONFIG_ENABLE_DRIVER_GPIO               1

/* definitions for UART */
#define CONFIG_ENABLE_DRIVER_UART               1
#define CONFIG_UART_DEFAULT_UART_IRQHANDLER     1
#define CONFIG_UART_ENABLE_INTERRUPT            1
#define CONFIG_UART_ENABLE_TX_INTERRUPT         1

#define CONFIG_ENABLE_DRIVER_PRINTF             1
//#define CONFIG_DRIVER_PRINTF_REDLIBV2           1

//#define DEBUG

 /* DRIVER_CONFIG_H_ */
#endif
