/*******************************************************************************
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
********************************************************************************
*
* Filename:          gpio.h
* Processor family:  LPC1227
*
* Description: This file contains GPIO code example which include GPIO
*              initialization, GPIO interrupt handler, and related APIs for
*              GPIO access.
*******************************************************************************/

#ifndef __GPIO_H
#define __GPIO_H

// igor - vymazat
#include	<driver_config.h>
//#include <ph_NxpBuild.h>

#if CONFIG_ENABLE_DRIVER_GPIO==1

#define PORT0              0
#define PORT1              1
#define PORT2              2

static LPC_GPIO_Type (* const LPC_GPIO[3]) = { LPC_GPIO0, LPC_GPIO1, LPC_GPIO2 };

void PIOINT0_IRQHandler(void);
void PIOINT1_IRQHandler(void);
void PIOINT2_IRQHandler(void);
void GPIOInit( void );
uint32_t	GPIOGetPin(uint32_t portNum, uint32_t bitPosi);
void GPIOSetInterrupt( uint32_t portNum, uint32_t bitPosi, uint32_t sense, uint32_t single, uint32_t event );
void GPIOIntEnable( uint32_t portNum, uint32_t bitPosi );
void GPIOIntDisable( uint32_t portNum, uint32_t bitPosi );
uint32_t GPIOIntStatus( uint32_t portNum, uint32_t bitPosi );
void GPIOIntClear( uint32_t portNum, uint32_t bitPosi );
void GPIOSetValue( uint32_t portNum, uint32_t bitPosi, uint32_t bitVal );
void GPIOSetDir( uint32_t portNum, uint32_t bitPosi, uint32_t dir );
#endif

#endif /* end __GPIO_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
