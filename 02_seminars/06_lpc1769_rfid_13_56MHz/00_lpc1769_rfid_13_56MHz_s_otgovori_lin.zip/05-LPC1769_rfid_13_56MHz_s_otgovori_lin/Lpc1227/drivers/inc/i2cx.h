/*
 * i2cx.h
 *
 *  Created on: 2 Apr 2014
 *      Author: nxp58740
 */

#ifndef I2CX_H_
#define I2CX_H_


/* Return Code in I2C status register */
#define I2STAT_CODE_BITMASK				((0xF8))

/** Mask for I2DAT register*/
#define I2DAT_BITMASK						((0xFF))

/* Master transmit mode -------------------------------------------- */
/** A start condition has been transmitted */
#define I2STAT_M_TX_START					((0x08))
/** A repeat start condition has been transmitted */
#define I2STAT_M_TX_RESTART					((0x10))
/** SLA+W has been transmitted, ACK has been received */
#define I2STAT_M_TX_SLAW_ACK				((0x18))
/** SLA+W has been transmitted, NACK has been received */
#define I2STAT_M_TX_SLAW_NACK				((0x20))
/** Data has been transmitted, ACK has been received */
#define I2STAT_M_TX_DAT_ACK					((0x28))
/** Data has been transmitted, NACK has been received */
#define I2STAT_M_TX_DAT_NACK				((0x30))
/** Arbitration lost in SLA+R/W or Data bytes */
#define I2STAT_M_TX_ARB_LOST				((0x38))

/* Master receive mode -------------------------------------------- */
/** A start condition has been transmitted */
#define I2STAT_M_RX_START					((0x08))
/** A repeat start condition has been transmitted */
#define I2STAT_M_RX_RESTART					((0x10))
/** Arbitration lost */
#define I2STAT_M_RX_ARB_LOST				((0x38))
/** SLA+R has been transmitted, ACK has been received */
#define I2STAT_M_RX_SLAR_ACK				((0x40))
/** SLA+R has been transmitted, NACK has been received */
#define I2STAT_M_RX_SLAR_NACK				((0x48))
/** Data has been received, ACK has been returned */
#define I2STAT_M_RX_DAT_ACK					((0x50))
/** Data has been received, NACK has been return */
#define I2STAT_M_RX_DAT_NACK				((0x58))

/* I2C status values */
#define I2C_SETUP_STATUS_ARBF				(1<<8)	/**< Arbitration false */
#define I2C_SETUP_STATUS_NOACKF				(1<<9)	/**< No ACK returned */
#define I2C_SETUP_STATUS_DONE				(1<<10)	/**< Status DONE */

typedef enum {FALSE = 0, TRUE = !FALSE} Bool;

typedef enum {ERROR = 0, SUCCESS = !ERROR} Status;

/**
 * @brief Master transfer setup data structure definitions
 */
typedef struct
{
  uint32_t          sl_addr7bit;				/**< Slave address in 7bit mode */
  uint8_t*          tx_data;					/**< Pointer to Transmit data - NULL if data transmit
													  is not used */
  uint32_t          tx_length;					/**< Transmit data length - 0 if data transmit
													  is not used*/
  uint32_t          tx_count;					/**< Current Transmit data counter */
  uint8_t*          rx_data;					/**< Pointer to Receive data - NULL if data receive
													  is not used */
  uint32_t          rx_length;					/**< Receive data length - 0 if data receive is
													   not used */
  uint32_t          rx_count;					/**< Current Receive data counter */
  uint32_t          retransmissions_max;		/**< Max Re-Transmission value */
  uint32_t          retransmissions_count;		/**< Current Re-Transmission counter */
  uint32_t          status;						/**< Current status of I2C activity */
  void 				(*callback)(void);			/**< Pointer to Call back function when transmission complete
													used in interrupt transfer mode */
} I2C_M_SETUP_Type;

#endif /* I2CX_H_ */
