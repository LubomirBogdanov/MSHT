/***********************************************************************************************
 *
 * Filename:     RegCtl_SpiHw.h
 * Author:       NXP
 * Revision:     1.0
 * Date:         August-2012
 *
 **********************************************************************************************/

#ifndef __REGCTL_SPIHW_H__
#define __REGCTL_SPIHW_H__

//#include <hw_config.h>
#include <driver_config.h>
#include <ph_Status.h>
#include <LPC122x.h>

/***********************************************************************************************
 **	Global macros and definitions
 ***********************************************************************************************/
#if CONFIG_ENABLE_DRIVER_SSP == 1

/* There are there modes in SSP: loopback, master or slave. */
/* Here are the combination of all the tests.
(1) LOOPBACK test:		LOOPBACK_MODE=1, TX_RX_ONLY=0, USE_CS=1;
(2) Serial EEPROM test:	LOOPBACK_MODE=0, TX_RX_ONLY=0, USE_CS=0; (default)
(3) TX(Master) Only:	LOOPBACK_MODE=0, SSP_SLAVE=0, TX_RX_ONLY=1, USE_CS=1;
(4) RX(Slave) Only:		LOOPBACK_MODE=0, SSP_SLAVE=1, TX_RX_ONLY=0, USE_CS=1 */

#define LOOPBACK_MODE		0	/* 1 is loopback, 0 is normal operation. */
#define SSP_SLAVE		      0	/* 1 is SLAVE mode, 0 is master mode */
#define TX_RX_ONLY		   0	/* 1 is TX or RX only depending on SSP_SLAVE
                               * flag, 0 is either loopback mode or communicate
                               * with a serial EEPROM. */

/* if USE_CS is zero, set SSEL as GPIO that you have total control of the sequence */
/* When test serial SEEPROM(LOOPBACK_MODE=0, TX_RX_ONLY=0), set USE_CS to 0. */
/* When LOOPBACK_MODE=1 or TX_RX_ONLY=1, set USE_CS to 1. */

#define USE_CS			      0
#define SSP_DEBUG		      0

/* SPI read and write buffer size */
#define SSP_BUFSIZE		   16
#define FIFOSIZE		      8

#define DELAY_COUNT		   10

/* Port0.2 is the SSP select pin */
#define SSP_SEL            (0x1<<2)

/* SSP Status register */
#define SSPSR_TFE          (0x1<<0)
#define SSPSR_TNF          (0x1<<1)
#define SSPSR_RNE          (0x1<<2)
#define SSPSR_RFF          (0x1<<3)
#define SSPSR_BSY          (0x1<<4)

/* SSP CR0 register */
#define SSPCR0_DSS         (0x1<<0)
#define SSPCR0_FRF         (0x1<<4)
#define SSPCR0_SPO         (0x1<<6)
#define SSPCR0_SPH         (0x1<<7)
#define SSPCR0_SCR         (0x1<<8)

/* SSP CR1 register */
#define SSPCR1_LBM         (0x1<<0)
#define SSPCR1_SSE         (0x1<<1)
#define SSPCR1_MS          (0x1<<2)
#define SSPCR1_SOD         (0x1<<3)

/* SSP Interrupt Mask Set/Clear register */
#define SSPIMSC_RORIM      (0x1<<0)
#define SSPIMSC_RTIM       (0x1<<1)
#define SSPIMSC_RXIM       (0x1<<2)
#define SSPIMSC_TXIM       (0x1<<3)

/* SSP0 Interrupt Status register */
#define SSPRIS_RORRIS      (0x1<<0)
#define SSPRIS_RTRIS       (0x1<<1)
#define SSPRIS_RXRIS       (0x1<<2)
#define SSPRIS_TXRIS       (0x1<<3)

/* SSP0 Masked Interrupt register */
#define SSPMIS_RORMIS      (0x1<<0)
#define SSPMIS_RTMIS       (0x1<<1)
#define SSPMIS_RXMIS       (0x1<<2)
#define SSPMIS_TXMIS       (0x1<<3)

/* SSP0 Interrupt clear register */
#define SSPICR_RORIC       (0x1<<0)
#define SSPICR_RTIC        (0x1<<1)

/* ATMEL SEEPROM command set */
#define WREN		         0x06		/* MSB A8 is set to 0, simplifying test */
#define WRDI         		0x04
#define RDSR	         	0x05
#define WRSR	         	0x01
#define READ	         	0x03
#define WRITE	         	0x02

/* RDSR status bit definition */
#define RDSR_RDY	         0x01
#define RDSR_WEN         	0x02

/* default defines */
#define SSEL_ASR	         0
#define SSEL_DEASR	      1

#define SSP_STATUS_TFE      ((uint8_t) 0x01)   /*!< TX FIFO empty. */
#define SSP_STATUS_TNF      ((uint8_t) 0x02)   /*!< TX FIFO not full.*/
#define SSP_STATUS_RNE      ((uint8_t) 0x04)   /*!< RX FIFO not empty. */
#define SSP_STATUS_RFF      ((uint8_t) 0x08)   /*!< RX FIFO full.*/
#define SSP_STATUS_BSY      ((uint8_t) 0x10)   /*!< SSP busy (during process of Tx or Rx.) */

/* SSP Status Implementation definitions */
#define SSP_STAT_DONE		(1UL<<8)		/**< Done */
#define SSP_STAT_ERROR		(1UL<<9)		/**< Error */

/* Private Macros ------------------------------------------------------------- */
/** @defgroup SSP_Private_Macros SSP Private Macros
 * @{
 */

/* --------------------- BIT DEFINITIONS -------------------------------------- */
/*********************************************************************//**
 * Macro defines for CR0 register
 **********************************************************************/
/** SSP data size select, must be 4 bits to 16 bits */
#define SSP_CR0_DSS(n)   		((uint32_t)((n-1)&0xF))
/** SSP control 0 Motorola SPI mode */
#define SSP_CR0_FRF_SPI  		((uint32_t)(0<<4))
/** SSP control 0 TI synchronous serial mode */
#define SSP_CR0_FRF_TI   		((uint32_t)(1<<4))
/** SSP control 0 National Micro-wire mode */
#define SSP_CR0_FRF_MICROWIRE  	((uint32_t)(2<<4))
/** SPI clock polarity bit (used in SPI mode only), (1) = maintains the
   bus clock high between frames, (0) = low */
#define SSP_CR0_CPOL_HI		((uint32_t)(1<<6))
/** SPI clock out phase bit (used in SPI mode only), (1) = captures data
   on the second clock transition of the frame, (0) = first */
#define SSP_CR0_CPHA_SECOND	((uint32_t)(1<<7))
/** SSP serial clock rate value load macro, divider rate is
   PERIPH_CLK / (cpsr * (SCR + 1)) */
#define SSP_CR0_SCR(n)   	((uint32_t)((n&0xFF)<<8))
/** SSP CR0 bit mask */
#define SSP_CR0_BITMASK		((uint32_t)(0xFFFF))

/*********************************************************************//**
 * Macro defines for CR1 register
 **********************************************************************/
/** SSP control 1 loopback mode enable bit */
#define SSP_CR1_LBM_EN		((uint32_t)(1<<0))
/** SSP control 1 enable bit */
#define SSP_CR1_SSP_EN		((uint32_t)(1<<1))
/** SSP control 1 slave enable */
#define SSP_CR1_SLAVE_EN	((uint32_t)(1<<2))
/** SSP control 1 slave out disable bit, disables transmit line in slave
   mode */
#define SSP_CR1_SO_DISABLE	((uint32_t)(1<<3))
/** SSP CR1 bit mask */
#define SSP_CR1_BITMASK		((uint32_t)(0x0F))

/*********************************************************************//**
 * Macro defines for DR register
 **********************************************************************/
/** SSP data bit mask */
#define SSP_DR_BITMASK(n)   ((n)&0xFFFF)

/*********************************************************************//**
 * Macro defines for SR register
 **********************************************************************/
/** SSP status TX FIFO Empty bit */
#define SSP_SR_TFE      ((uint32_t)(1<<0))
/** SSP status TX FIFO not full bit */
#define SSP_SR_TNF      ((uint32_t)(1<<1))
/** SSP status RX FIFO not empty bit */
#define SSP_SR_RNE      ((uint32_t)(1<<2))
/** SSP status RX FIFO full bit */
#define SSP_SR_RFF      ((uint32_t)(1<<3))
/** SSP status SSP Busy bit */
#define SSP_SR_BSY      ((uint32_t)(1<<4))
/** SSP SR bit mask */
#define SSP_SR_BITMASK	((uint32_t)(0x1F))

/*********************************************************************//**
 * Macro defines for CPSR register
 **********************************************************************/
/** SSP clock prescaler */
#define SSP_CPSR_CPDVSR(n) 	((uint32_t)(n&0xFF))
/** SSP CPSR bit mask */
#define SSP_CPSR_BITMASK	((uint32_t)(0xFF))

/*********************************************************************//**
 * Macro define for (IMSC) Interrupt Mask Set/Clear registers
 **********************************************************************/
/** Receive Overrun */
#define SSP_IMSC_ROR	((uint32_t)(1<<0))
/** Receive TimeOut */
#define SSP_IMSC_RT		((uint32_t)(1<<1))
/** Rx FIFO is at least half full */
#define SSP_IMSC_RX		((uint32_t)(1<<2))
/** Tx FIFO is at least half empty */
#define SSP_IMSC_TX		((uint32_t)(1<<3))
/** IMSC bit mask */
#define SSP_IMSC_BITMASK	((uint32_t)(0x0F))

/*********************************************************************//**
 * Macro define for (RIS) Raw Interrupt Status registers
 **********************************************************************/
/** Receive Overrun */
#define SSP_RIS_ROR		((uint32_t)(1<<0))
/** Receive TimeOut */
#define SSP_RIS_RT		((uint32_t)(1<<1))
/** Rx FIFO is at least half full */
#define SSP_RIS_RX		((uint32_t)(1<<2))
/** Tx FIFO is at least half empty */
#define SSP_RIS_TX		((uint32_t)(1<<3))
/** RIS bit mask */
#define SSP_RIS_BITMASK	((uint32_t)(0x0F))

/*********************************************************************//**
 * Macro define for (MIS) Masked Interrupt Status registers
 **********************************************************************/
/** Receive Overrun */
#define SSP_MIS_ROR		((uint32_t)(1<<0))
/** Receive TimeOut */
#define SSP_MIS_RT		((uint32_t)(1<<1))
/** Rx FIFO is at least half full */
#define SSP_MIS_RX		((uint32_t)(1<<2))
/** Tx FIFO is at least half empty */
#define SSP_MIS_TX		((uint32_t)(1<<3))
/** MIS bit mask */
#define SSP_MIS_BITMASK	((uint32_t)(0x0F))

/*********************************************************************//**
 * Macro define for (ICR) Interrupt Clear registers
 **********************************************************************/
/** Writing a 1 to this bit clears the "frame was received when
 * RxFIFO was full" interrupt */
#define SSP_ICR_ROR		((uint32_t)(1<<0))
/** Writing a 1 to this bit clears the "Rx FIFO was not empty and
 * has not been read for a timeout period" interrupt */
#define SSP_ICR_RT		((uint32_t)(1<<1))
/** ICR bit mask */
#define SSP_ICR_BITMASK	((uint32_t)(0x03))

/***********************************************************************************************
 **	Global variables
 ***********************************************************************************************/

/***********************************************************************************************
 **	Global function prototypes
 ***********************************************************************************************/
/* If RX_INTERRUPT is enabled, the SSP RX will be handled in the ISR
SSPReceive() will not be needed. */
extern void SSP_IRQHandler (void);
extern void SSP_IOConfig( void );
extern void SSP_Init( void );
extern void SSP_Send( uint8_t *Buf, uint32_t Length );
extern void SSP_Receive( uint8_t *buf, uint32_t Length );
// igor - vymazat 
// extern void SSP_Exhange( uint8_t *bufIn, uint8_t *bufOut, uint32_t Length );
// extern int32_t SSP_ReadWrite (LPC_SSP_Type *SSPx, SSP_DATA_SETUP_Type *dataCfg);
#endif // CONFIG_ENABLE_DRIVER_SSP==1



#endif  // __REGCTL_SPIHW_H__


/***********************************************************************************************
 **                            End Of File
 ***********************************************************************************************/
