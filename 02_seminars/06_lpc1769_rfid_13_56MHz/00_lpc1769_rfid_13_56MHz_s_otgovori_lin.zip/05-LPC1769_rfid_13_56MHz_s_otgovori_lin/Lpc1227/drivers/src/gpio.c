/*******************************************************************************
*         Copyright (c), NXP Semiconductors Gratkorn / Austria
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
********************************************************************************
*
* Filename:          gpio.c
* Processor family:  LPC1227
*
* Description: This file contains GPIO code example which include GPIO
*              initialization, GPIO interrupt handler, and related APIs for
*              GPIO access.
*******************************************************************************/

#include <driver_config.h>
#if CONFIG_ENABLE_DRIVER_GPIO==1
#include <gpio.h>

#if CONFIG_GPIO_DEFAULT_PIOINT0_IRQHANDLER==1
volatile uint32_t gpio0_counter = 0;
volatile uint32_t p0_1_counter  = 0;
/*****************************************************************************
** Function name:		PIOINT0_IRQHandler
**
** Descriptions:		Use one GPIO pin(port0 pin1) as interrupt source
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void PIOINT0_IRQHandler(void)
{
  uint32_t regVal;

  gpio0_counter++;
  regVal = GPIOIntStatus( PORT0, 12 );
  if ( regVal )
  {
	p0_1_counter++;
	GPIOIntClear( PORT0, 12 );
  }
  return;
}
#endif

#if CONFIG_GPIO_DEFAULT_PIOINT1_IRQHANDLER==1
volatile uint32_t gpio1_counter = 0;
volatile uint32_t p1_1_counter  = 0;
/*****************************************************************************
** Function name:		PIOINT1_IRQHandler
**
** Descriptions:		Use one GPIO pin(port1 pin1) as interrupt source
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void PIOINT1_IRQHandler(void)
{
  uint32_t regVal;

  gpio1_counter++;
  regVal = GPIOIntStatus( PORT1, 5 );
  if ( regVal )
  {
	p1_1_counter++;
	GPIOIntClear( PORT1, 5 );
  }
  return;
}
#endif

#if CONFIG_GPIO_DEFAULT_PIOINT2_IRQHANDLER==1
volatile uint32_t gpio2_counter = 0;
volatile uint32_t p2_1_counter  = 0;
/*****************************************************************************
** Function name:		PIOINT2_IRQHandler
**
** Descriptions:		Use one GPIO pin(port2 pin1) as interrupt source
**
** parameters:			None
** Returned value:		None
** 
*****************************************************************************/
void PIOINT2_IRQHandler(void)
    {
  uint32_t regVal;

  gpio2_counter++;
  regVal = GPIOIntStatus( PORT2, 0 );
  if ( regVal )
  {
	p2_1_counter++;
	GPIOIntClear( PORT2, 0 );
  }
  return;
    }
#endif

/*****************************************************************************
** Function name:		GPIOInit
**
** Descriptions:		Initialize GPIO, install the
**						GPIO interrupt handler
**
** parameters:			None
** Returned value:		true or false, return false if the VIC table
**						is full and GPIO interrupt handler can be
**						installed.
** 
*****************************************************************************/
void GPIOInit( void )
{
  /* Enable AHB clock to the GPIO domain. */
    /* GPIO_0 */
    LPC_SYSCON->SYSAHBCLKCTRL |= ( 0x1 << 31 );
    /* GPIO_1 */
    LPC_SYSCON->SYSAHBCLKCTRL |= ( 0x1 << 30 );
    /* GPIO_2 */
    LPC_SYSCON->SYSAHBCLKCTRL |= ( 0x1 << 29 );

#ifdef __JTAG_DISABLED  
  LPC_IOCON->R_PIO1_1  &= ~0x07;
  LPC_IOCON->R_PIO1_1  |= 0x01;
#endif

  /* Set up NVIC when I/O pins are configured as external interrupts. */
#if CONFIG_GPIO_DEFAULT_PIOINT0_IRQHANDLER==1
  NVIC_EnableIRQ(EINT0_IRQn);
#endif
#if CONFIG_GPIO_DEFAULT_PIOINT1_IRQHANDLER==1
  NVIC_EnableIRQ(EINT1_IRQn);
#endif
#if CONFIG_GPIO_DEFAULT_PIOINT2_IRQHANDLER==1
  NVIC_EnableIRQ(EINT2_IRQn);
#endif
  return;
}

uint32_t	GPIOGetPin(uint32_t portNum, uint32_t bitPosi)
{
	return (LPC_GPIO[portNum]->PIN & (1<<bitPosi));
}
/*****************************************************************************
** Function name:		GPIOSetInterrupt
**
** Descriptions:		Set interrupt sense, event, etc.
**						edge or level, 0 is edge, 1 is level
**						single or double edge, 0 is single, 1 is double 
**						active high or low, etc.
**
** parameters:			port num, bit position, sense, single/doube, polarity
** Returned value:		None
** 
*****************************************************************************/
void GPIOSetInterrupt( uint32_t portNum, uint32_t bitPosi, uint32_t sense,
			uint32_t single, uint32_t event )
{
  switch ( portNum )
      {
      case PORT0:
	  if ( sense == 0 )
	      {
		LPC_GPIO0->IS &= ~(0x1<<bitPosi);
		/* single or double only applies when sense is 0(edge trigger). */
		if ( single == 0 )
		  LPC_GPIO0->IBE &= ~(0x1<<bitPosi);
		else
		  LPC_GPIO0->IBE |= (0x1<<bitPosi);
	      }
	  else
	      {
	      LPC_GPIO0->IS |= (0x1<<bitPosi);
	      }
	  if ( event == 0 )
		LPC_GPIO0->IEV &= ~(0x1<<bitPosi);
	  else
		LPC_GPIO0->IEV |= (0x1<<bitPosi);
	  break;
      case PORT1:
	  if ( sense == 0 )
	      {
	      LPC_GPIO1->IS &= ~(0x1<<bitPosi);
	      /* single or double only applies when sense is 0(edge trigger). */
	      if ( single == 0 )
		  LPC_GPIO1->IBE &= ~(0x1<<bitPosi);
	      else
		  LPC_GPIO1->IBE |= (0x1<<bitPosi);
	      }
	  else
	      LPC_GPIO1->IS |= (0x1<<bitPosi);
	  if ( event == 0 )
	      LPC_GPIO1->IEV &= ~(0x1<<bitPosi);
	  else
		LPC_GPIO1->IEV |= (0x1<<bitPosi);  
	break;

 	case PORT2:
	  if ( sense == 0 )
	  {
		LPC_GPIO2->IS &= ~(0x1<<bitPosi);
		/* single or double only applies when sense is 0(edge trigger). */
		if ( single == 0 )
		  LPC_GPIO2->IBE &= ~(0x1<<bitPosi);
		else
		  LPC_GPIO2->IBE |= (0x1<<bitPosi);
	  }
	  else
	  	LPC_GPIO2->IS |= (0x1<<bitPosi);
	  if ( event == 0 )
		LPC_GPIO2->IEV &= ~(0x1<<bitPosi);
	  else
		LPC_GPIO2->IEV |= (0x1<<bitPosi);  
	break;

 	default:
	  break;
  }
  return;
}

/*****************************************************************************
** Function name:		GPIOIntEnable
**
** Descriptions:		Enable Interrupt Mask for a port pin.
**
** parameters:			port num, bit position
** Returned value:		None
** 
*****************************************************************************/
void GPIOIntEnable( uint32_t portNum, uint32_t bitPosi )
{
    LPC_GPIO[portNum]->IE |= ( 0x1 << bitPosi );
  return;
}

/*****************************************************************************
** Function name:		GPIOIntDisable
**
** Descriptions:		Disable Interrupt Mask for a port pin.
**
** parameters:			port num, bit position
** Returned value:		None
** 
*****************************************************************************/
void GPIOIntDisable( uint32_t portNum, uint32_t bitPosi )
{
    LPC_GPIO[portNum]->IE &= ~( 0x1 << bitPosi );
  return;
}

/*****************************************************************************
** Function name:		GPIOIntStatus
**
** Descriptions:		Get Interrupt status for a port pin.
**
** parameters:			port num, bit position
** Returned value:		None
** 
*****************************************************************************/
uint32_t GPIOIntStatus( uint32_t portNum, uint32_t bitPosi )
{
    uint32_t regVal = 0;

    if ( LPC_GPIO[portNum]->MIS & ( 0x1 << bitPosi ))
	{
	regVal = 1;
	}
  return ( regVal );
}

/*****************************************************************************
** Function name:		GPIOIntClear
**
** Descriptions:		Clear Interrupt for a port pin.
**
** parameters:			port num, bit position
** Returned value:		None
** 
*****************************************************************************/
void GPIOIntClear( uint32_t portNum, uint32_t bitPosi )
{
    LPC_GPIO[portNum]->IC |= ( 0x1 << bitPosi );
    return;
}

/*****************************************************************************
** Function name:		GPIOSetValue
**
** Descriptions:		Set/clear a bitvalue in a specific bit position
**						in GPIO portX(X is the port number.)
**
** parameters:			port num, bit position, bit value
** Returned value:		None
**
*****************************************************************************/
void GPIOSetValue( uint32_t portNum, uint32_t bitPosi, uint32_t bitVal )
{
    if ( bitVal )
	{
	/* bitVal = 1, set the value on the output pin*/
	LPC_GPIO[portNum]->SET = ( 0x1 << bitPosi );
	}
    else
	{
	/* bitVal = 0, clear the value on the output pin*/
	LPC_GPIO[portNum]->CLR = ( 0x1 << bitPosi );
	}
}

/*****************************************************************************
** Function name:		GPIOSetDir
**
** Descriptions:		Set the direction in GPIO port
**
** parameters:			port num, bit position, direction (1 out, 0 input)
** Returned value:		None
**
*****************************************************************************/
void GPIOSetDir( uint32_t portNum, uint32_t bitPosi, uint32_t dir )
{
  if(dir)
      {
      LPC_GPIO[portNum]->DIR |= ( 0x1 << bitPosi );
      }
  else
      {
      LPC_GPIO[portNum]->DIR &= ~( 0x1 << bitPosi );
      }
}
#endif

/******************************************************************************
**                            End Of File
******************************************************************************/
