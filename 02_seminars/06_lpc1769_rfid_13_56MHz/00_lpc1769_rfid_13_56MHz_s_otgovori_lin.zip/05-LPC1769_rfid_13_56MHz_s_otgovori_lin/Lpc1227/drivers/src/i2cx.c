/*
 * LPC_I2C.c
 *
 *  Created on: 2 Apr 2014
 *      Author: nxp58740
 */


/**********************************************************************
* $Id$		lpc17xx_gpio.c				2011-03-31
*//**
* @file		lpc17xx_gpio.c
* @brief	Contains all functions support for I2C firmware
* 			library on LPC17xx
* @version	2.1
* @date		31. Mar. 2011
* @author	NXP MCU SW Application Team
*
* Copyright(C) 2010, NXP Semiconductor
* All rights reserved.
*
***********************************************************************
* Software that is described herein is for illustrative purposes only
* which provides customers with programming information regarding the
* products. This software is supplied "AS IS" without any warranties.
* NXP Semiconductors assumes no responsibility or liability for the
* use of the software, conveys no license or title under any patent,
* copyright, or mask work right to the product. NXP Semiconductors
* reserves the right to make changes in the software without
* notification. NXP Semiconductors also make no representation or
* warranty that such application will be suitable for the specified
* use without further testing or modification.
**********************************************************************/

/* Peripheral group ----------------------------------------------------------- */
/** @addtogroup I2C
 * @{
 */

/* Includes ------------------------------------------------------------------- */
#include <i2c.h>
#include <i2cx.h>
#include <LPC122x.h>
#include <type.h>

#if 1

/* Private Types -------------------------------------------------------------- */
/** @defgroup I2C_Private_Types I2C Private Types
 * @{
 */

/**
 * @brief I2C device configuration structure type
 */
typedef struct
{
  uint32_t      txrx_setup; 						/* Transmission setup */
  int32_t		dir;								/* Current direction phase, 0 - write, 1 - read */
} I2C_CFG_T;

/**
 * @}
 */

/* Private Variables ---------------------------------------------------------- */
/**
 * @brief II2C driver data for I2C0, I2C1 and I2C2
 */

/* Private Functions ---------------------------------------------------------- */

/* Generate a start condition on I2C bus (in master mode only) */
static uint32_t I2C_Start();

/* Generate a stop condition on I2C bus (in master mode only) */
static void I2C_Stop();

/* I2C send byte subroutine */
static uint32_t I2C_SendByte(uint8_t databyte);

/* I2C get byte subroutine */
static uint32_t I2C_GetByte(uint8_t *retdat, Bool ack);

/*--------------------------------------------------------------------------------*/
/********************************************************************//**
 * @brief		Generate a start condition on I2C bus (in master mode only)
 * @param[in]	LPC_I2C: I2C peripheral selected, should be:
 * 				- LPC_I2C0
 * 				- LPC_I2C1
 * 				- LPC_I2C2
 * @return 		value of I2C status register after generate a start condition
 *********************************************************************/
static uint32_t I2C_Start()
{
	LPC_I2C->CONSET = I2CONSET_STA;
	LPC_I2C->CONCLR = I2CONCLR_SIC;

	// Wait for complete
	while (!(LPC_I2C->CONSET & I2CONSET_SI));
	LPC_I2C->CONCLR = I2CONCLR_STAC;
	return (LPC_I2C->STAT & I2STAT_CODE_BITMASK);
}

/********************************************************************//**
 * @brief		Generate a stop condition on I2C bus (in master mode only)
 * @param[in]	LPC_I2C: I2C peripheral selected, should be:
 * 				- LPC_I2C0
 * 				- LPC_I2C1
 * 				- LPC_I2C2
 * @return 		None
 *********************************************************************/
static void I2C_Stop()
{

	/* Make sure start bit is not active */
	if (LPC_I2C->CONSET & I2CONSET_STA)
	{
		LPC_I2C->CONCLR = I2CONCLR_STAC;
	}
	LPC_I2C->CONSET = I2CONSET_STO;
	LPC_I2C->CONCLR = I2CONCLR_SIC;
}

/********************************************************************//**
 * @brief		Send a byte
 * @param[in]	LPC_I2C: I2C peripheral selected, should be:
 * 				- LPC_I2C0
 * 				- LPC_I2C1
 * 				- LPC_I2C2
 * @param[in]	databyte: number of byte
 * @return 		value of I2C status register after sending
 *********************************************************************/
static uint32_t I2C_SendByte(uint8_t databyte)
{
	/* Make sure start bit is not active */
	if (LPC_I2C->CONSET & I2CONSET_STA)
	{
		LPC_I2C->CONCLR = I2CONCLR_STAC;
	}
	LPC_I2C->DAT = databyte & I2DAT_BITMASK;
	LPC_I2C->CONCLR = I2CONCLR_SIC;

	while (!(LPC_I2C->CONSET & I2CONSET_SI));
	return (LPC_I2C->STAT & I2STAT_CODE_BITMASK);
}

/********************************************************************//**
 * @brief		Get a byte
 * @param[in]	LPC_I2C: I2C peripheral selected, should be:
 * 				- LPC_I2C0
 * 				- LPC_I2C1
 * 				- LPC_I2C2
 * @param[out]	retdat	pointer to return data
 * @param[in]	ack		assert acknowledge or not, should be: TRUE/FALSE
 * @return 		value of I2C status register after sending
 *********************************************************************/
static uint32_t I2C_GetByte(uint8_t *retdat, Bool ack)
{
	if (ack == TRUE)
	{
		LPC_I2C->CONSET = I2CONSET_AA;
	}
	else
	{
		LPC_I2C->CONCLR = I2CONCLR_AAC;
	}
	LPC_I2C->CONCLR = I2CONCLR_SIC;

	while (!(LPC_I2C->CONSET & I2CONSET_SI));
	*retdat = (uint8_t) (LPC_I2C->DAT & I2DAT_BITMASK);
	return (LPC_I2C->STAT & I2STAT_CODE_BITMASK);
}

/* End of Private Functions --------------------------------------------------- */


/* Public Functions ----------------------------------------------------------- */
/** @addtogroup I2C_Public_Functions
 * @{
 */
/*********************************************************************//**
 * @brief 		Transmit and Receive data in master mode
 * @param[in]	LPC_I2C			I2C peripheral selected, should be:
 *  			- LPC_I2C0
 * 				- LPC_I2C1
 * 				- LPC_I2C2
 * @param[in]	TransferCfg		Pointer to a I2C_M_SETUP_Type structure that
 * 								contains specified information about the
 * 								configuration for master transfer.
 * @param[in]	Opt				a I2C_TRANSFER_OPT_Type type that selected for
 * 								interrupt or polling mode.
 * @return 		SUCCESS or ERROR
 *
 * Note:
 * - In case of using I2C to transmit data only, either transmit length set to 0
 * or transmit data pointer set to NULL.
 * - In case of using I2C to receive data only, either receive length set to 0
 * or receive data pointer set to NULL.
 * - In case of using I2C to transmit followed by receive data, transmit length,
 * transmit data pointer, receive length and receive data pointer should be set
 * corresponding.
 **********************************************************************/
Status I2C_MasterTransferData(I2C_M_SETUP_Type *TransferCfg)
{
	volatile uint8_t *txdat;
	volatile uint8_t *rxdat;
	volatile uint32_t CodeStatus;
	volatile uint8_t tmp;

	// reset all default state
	txdat = (uint8_t *) TransferCfg->tx_data;
	rxdat = (uint8_t *) TransferCfg->rx_data;
	// Reset I2C setup value to default state
	TransferCfg->tx_count = 0;
	TransferCfg->rx_count = 0;
	TransferCfg->status = 0;

	/* First Start condition -------------------------------------------------------------- */
	TransferCfg->retransmissions_count = 0;

retry:
	// reset all default state
	txdat = (uint8_t *) TransferCfg->tx_data;
	rxdat = (uint8_t *) TransferCfg->rx_data;
	// Reset I2C setup value to default state
	TransferCfg->tx_count = 0;
	TransferCfg->rx_count = 0;
	CodeStatus = 0;

	// Start command
	CodeStatus = I2C_Start();
	if ((CodeStatus != I2STAT_M_TX_START) \
			&& (CodeStatus != I2STAT_M_TX_RESTART)){
		TransferCfg->retransmissions_count++;
		if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
			// save status
			TransferCfg->status = CodeStatus;
			goto error;
		}
		else
			goto retry;
	}

	/* In case of sending data first --------------------------------------------------- */
	if ((TransferCfg->tx_length != 0) && (TransferCfg->tx_data != NULL)){

		/* Send slave address + WR direction bit = 0 ----------------------------------- */
		CodeStatus = I2C_SendByte((TransferCfg->sl_addr7bit << 1));
		if (CodeStatus != I2STAT_M_TX_SLAW_ACK){
			TransferCfg->retransmissions_count++;
			if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
				// save status
				TransferCfg->status = CodeStatus | I2C_SETUP_STATUS_NOACKF;
				goto error;
			}
			else
				goto retry;
		}

		/* Send a number of data bytes ---------------------------------------- */
		while (TransferCfg->tx_count < TransferCfg->tx_length)
		{
			CodeStatus = I2C_SendByte(*txdat);
			if (CodeStatus != I2STAT_M_TX_DAT_ACK){
				TransferCfg->retransmissions_count++;
				if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
					// save status
					TransferCfg->status = CodeStatus | I2C_SETUP_STATUS_NOACKF;
					goto error;
				}
				else
					goto retry;
			}

			txdat++;
			TransferCfg->tx_count++;
		}
	}

	/* Second Start condition (Repeat Start) ------------------------------------------- */
	if ((TransferCfg->tx_length != 0) && (TransferCfg->tx_data != NULL) \
			&& (TransferCfg->rx_length != 0) && (TransferCfg->rx_data != NULL)){

		CodeStatus = I2C_Start();
		if ((CodeStatus != I2STAT_M_RX_START) \
				&& (CodeStatus != I2STAT_M_RX_RESTART)){
			TransferCfg->retransmissions_count++;
			if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
				// Update status
				TransferCfg->status = CodeStatus;
				goto error;
			}
			else
				goto retry;
		}
	}

	/* Then, start reading after sending data -------------------------------------- */
	if ((TransferCfg->rx_length != 0) && (TransferCfg->rx_data != NULL)){
		/* Send slave address + RD direction bit = 1 ----------------------------------- */

		CodeStatus = I2C_SendByte(((TransferCfg->sl_addr7bit << 1) | 0x01));
		if (CodeStatus != I2STAT_M_RX_SLAR_ACK){
			TransferCfg->retransmissions_count++;
			if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
				// update status
				TransferCfg->status = CodeStatus | I2C_SETUP_STATUS_NOACKF;
				goto error;
			}
			else
				goto retry;
		}

		/* Receive a number of data bytes ------------------------------------------------- */
		while (TransferCfg->rx_count < TransferCfg->rx_length){

			/*
			 * Note that: if data length is only one, the master should not
			 * issue an ACK signal on bus after reading to avoid of next data frame
			 * on slave side
			 */
			if (TransferCfg->rx_count < (TransferCfg->rx_length - 1)){
				// Issue an ACK signal for next data frame
				CodeStatus = I2C_GetByte(&tmp, 1);
				if (CodeStatus != I2STAT_M_RX_DAT_ACK){
					TransferCfg->retransmissions_count++;
					if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
						// update status
						TransferCfg->status = CodeStatus;
						goto error;
					}
					else
						goto retry;
				}
			}
			else{
				// Do not issue an ACK signal
				CodeStatus = I2C_GetByte(&tmp, 0);
				if (CodeStatus != I2STAT_M_RX_DAT_NACK){
					TransferCfg->retransmissions_count++;
					if (TransferCfg->retransmissions_count > TransferCfg->retransmissions_max){
						// update status
						TransferCfg->status = CodeStatus;
						goto error;
					}
					else
						goto retry;
				}
			}
			*rxdat++ = tmp;
			TransferCfg->rx_count++;
		}
	}

	/* Send STOP condition ------------------------------------------------- */
	I2C_Stop();
	return SUCCESS;

error:
	// Send stop condition
	I2C_Stop();
	return ERROR;

}
/**
 * @}
 */

#endif /* _I2C */

/**
 * @}
 */

/* --------------------------------- End Of File ------------------------------ */
