==============================================================================
Readme - Software for the PNEV512B Blueboard and CLEV663B Blueboard
==============================================================================

1. Document purpose

This document describes the content of the source package as well as known
problems and restrictions.
A separate User Manual describes the first steps how to use the software in
combination with the Hardware.

2. Known problems and restrictions

* Restrictions
The Software is restricted to the PNEV512B Blueboard and CLEV663B Blueboard. The API is intended for
the NXP contactless/contact reader ICs, as such the API is not to be ported to any technology from
any other vendor.
The Software is running on a ARM Cortex M0 LPC1227/301 controller from NXP. 
NXP will not support porting to any other vendor platform. 

This project is intended to be used together with a
NFC Reader Library project and an application project.

* Known Problems

  LPC1227 able to host Client only.
  
  When hosting Target, bus bitrate needs to be set to cca 1.5MHz
  for I2C bus:
  drivers/src/i2c.c
  line 375 LPC_I2C->SCLL   = I2SCLH_SCLH_360_KHZ/5;
  line 376 LPC_I2C->SCLH   = I2SCLL_SCLL_360_KHZ/5;
  for SPI bus:
  dirvers/src/ssp.c
  line 159 LPC_SSP->CPSR = 0x02; 
  
  When running as Initiator and communicating with LPC1769 peer, I2C 360kHz or SPI 750kHz recommended.
  for I2C bus:
  drivers/src/i2c.c
  line 375 LPC_I2C->SCLL   = I2SCLH_SCLH_360_KHZ/1;
  line 376 LPC_I2C->SCLH   = I2SCLL_SCLL_360_KHZ/1;
  for SPI bus:
  dirvers/src/ssp.c
  line 159 LPC_SSP->CPSR = 0x04; 
  
	
3. Content

Lpc1227 (Eclipse project) content:
│   .cproject                   // LPCXpresso Project file
│   .project                    // LPCXpresso Project file
│   aeabi_romdiv_patch.s
│   crp.c
│   phhwConfig.c
│   phhwConfig.h
│   Readme.txt                  // This Readme file
│
├───CMSIS
│   ├───inc
│   │       core_cm0.h
│   │       core_cmFunc.h
│   │       core_cmInstr.h
│   │       LPC122x.h
│   │       LPC12xx.h
│   │       system_LPC122x.h
│   │       system_LPC12xx.h
│   │
│   └───src
│           system_LPC122x.c
│
├───drivers
│   ├───inc
│   │       driver_config.h
│   │       gpio.h
│   │       i2c.h
│   │       i2cx.h
│   │       ssp.h
│   │       type.h
│   │
│   └───src
│           gpio.c
│           i2c.c
│           i2cx.c
│           ssp.c
│
├───startup
│       cr_startup_lpc12xx.c
│
└───Stub
        phbalReg_Stub.c
        phOsal_Lpc12xx_Int.c
        phOsal_Lpc12xx_Int.h
        phOsal_Stub.c

4. Mandatory material, not included

* LPCXpresso IDE as described on the web site:
	http://www.lpcware.com/lpcxpresso
* LPCXpresso LPC1227 development board

5. Revision History

V1.1:
* Updated the startup code
* Added the ROM divide patch
* Corrected the Symbol definitions in the project settings
V1.0:
* First packaged version.