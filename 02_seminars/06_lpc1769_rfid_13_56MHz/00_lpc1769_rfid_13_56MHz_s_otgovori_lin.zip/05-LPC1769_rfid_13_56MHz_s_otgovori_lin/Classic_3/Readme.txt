==============================================================================
Readme - Software for the PNEV512B Blueboard and CLEV663B Blueboard
==============================================================================

1. Document purpose

This document describes the content of the source package as well as known
problems and restrictions.
A separate User Manual describes the first steps how to use the software in
combination with the Hardware.

2. Known problems and restrictions

* Restrictions
The Software is restricted to the PNEV512B Blueboard and CLEV663B Blueboard. The API is intended for
the NXP contactless/contact reader ICs, as such the API is not to be ported to any technology from
any other vendor.
The Software is running on a Cortex M0 LPC1227/301 as well as on a Cortex M3 LPC1769 controller
from NXP. 
NXP will not support porting to any other vendor platform. 

This software project requires at least the NFC Reader Library version 3.010.00.001407.

To get this project running, you need also the NFC Reader Library project and, depending on the used
micro controller, a LPC project.

* Known Problems

  - none
	
3. Content

Classic (Eclipse project) content:
�   .cproject
�   .project
�   main.c
�   Readme.txt  (this readme file)

4. Mandatory material, not included

* LPCXpresso IDE as described on the web site:
	http://www.lpcware.com/lpcxpresso
* LPCXpresso LPC1227 or LPC1769 development board

5. Revision History

V1.2:
* Corrected some Symbol definitions in the build configs for the LPC1227
* Clean up of the main.c
V1.1:
* Cut out of the NFC Reader Library and the MCU depended files into separate projects.
* Using the discovery loop for tag discovery.
V1.0:
* First packaged version.